self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "92cd118350fcfd35febc1c50fbff1c20",
    "url": "/index.html"
  },
  {
    "revision": "f31edfd7706567e7d741",
    "url": "/static/css/0.85a10d36.chunk.css"
  },
  {
    "revision": "080c11de1d422821f36a",
    "url": "/static/css/1.27359a02.chunk.css"
  },
  {
    "revision": "4a8a52fc7942fefeafd0",
    "url": "/static/css/10.72be70d6.chunk.css"
  },
  {
    "revision": "3c55b746feb60b0d78eb",
    "url": "/static/css/11.5d4c3ae9.chunk.css"
  },
  {
    "revision": "d5db9baac64a052fd367",
    "url": "/static/css/12.dd0cfdb4.chunk.css"
  },
  {
    "revision": "35121849385e57bc4069",
    "url": "/static/css/13.66c5db99.chunk.css"
  },
  {
    "revision": "2eb5d2ca1c30c772c838",
    "url": "/static/css/14.d437c6df.chunk.css"
  },
  {
    "revision": "33c1c31f016595eb98fe",
    "url": "/static/css/15.df885bc0.chunk.css"
  },
  {
    "revision": "f3ea1f484539e5184081",
    "url": "/static/css/16.a56a3f13.chunk.css"
  },
  {
    "revision": "9226354dc9d4d0d096e5",
    "url": "/static/css/17.bd466da3.chunk.css"
  },
  {
    "revision": "629578142df7821a6db1",
    "url": "/static/css/18.bd466da3.chunk.css"
  },
  {
    "revision": "b5b0ef7bf229a444c2b9",
    "url": "/static/css/19.c292fc4e.chunk.css"
  },
  {
    "revision": "27a91ff1da48a321f4a4",
    "url": "/static/css/20.91b159ee.chunk.css"
  },
  {
    "revision": "45775f196e271f1d1ca7",
    "url": "/static/css/21.b71ec609.chunk.css"
  },
  {
    "revision": "fa3d5b5d4a78efb633d7",
    "url": "/static/css/22.08e42eba.chunk.css"
  },
  {
    "revision": "b638cfac0840f4a0dbe2",
    "url": "/static/css/23.0005e3ed.chunk.css"
  },
  {
    "revision": "9b2f4169ad0c247ff364",
    "url": "/static/css/24.fefc1cf1.chunk.css"
  },
  {
    "revision": "e5b1a7b02eef5e28d508",
    "url": "/static/css/25.425eb572.chunk.css"
  },
  {
    "revision": "c3fb3bffd09bdaa5c3d7",
    "url": "/static/css/26.df5daa47.chunk.css"
  },
  {
    "revision": "d9f1dc200485194a9fde",
    "url": "/static/css/3.c0890918.chunk.css"
  },
  {
    "revision": "06e7efc2e13b48c31b62",
    "url": "/static/css/4.2135f300.chunk.css"
  },
  {
    "revision": "cf45c131b50a81a9c60b",
    "url": "/static/css/5.0110d23d.chunk.css"
  },
  {
    "revision": "698aeceff16ed25bec0e",
    "url": "/static/css/6.88a65b9e.chunk.css"
  },
  {
    "revision": "44d110ffd34196d2f02a",
    "url": "/static/css/9.63b78e45.chunk.css"
  },
  {
    "revision": "32f6e92e72b75f92cda6",
    "url": "/static/css/main.705d9c9f.chunk.css"
  },
  {
    "revision": "f31edfd7706567e7d741",
    "url": "/static/js/0.a06b53d5.chunk.js"
  },
  {
    "revision": "080c11de1d422821f36a",
    "url": "/static/js/1.efdd0ffa.chunk.js"
  },
  {
    "revision": "4a8a52fc7942fefeafd0",
    "url": "/static/js/10.f3f947d5.chunk.js"
  },
  {
    "revision": "3c55b746feb60b0d78eb",
    "url": "/static/js/11.c8b75470.chunk.js"
  },
  {
    "revision": "d5db9baac64a052fd367",
    "url": "/static/js/12.adef0f57.chunk.js"
  },
  {
    "revision": "35121849385e57bc4069",
    "url": "/static/js/13.ad5e4ddc.chunk.js"
  },
  {
    "revision": "2eb5d2ca1c30c772c838",
    "url": "/static/js/14.042028a5.chunk.js"
  },
  {
    "revision": "33c1c31f016595eb98fe",
    "url": "/static/js/15.032e7f60.chunk.js"
  },
  {
    "revision": "f3ea1f484539e5184081",
    "url": "/static/js/16.5b964022.chunk.js"
  },
  {
    "revision": "9226354dc9d4d0d096e5",
    "url": "/static/js/17.e784a4f9.chunk.js"
  },
  {
    "revision": "629578142df7821a6db1",
    "url": "/static/js/18.2c391be6.chunk.js"
  },
  {
    "revision": "b5b0ef7bf229a444c2b9",
    "url": "/static/js/19.e91b505e.chunk.js"
  },
  {
    "revision": "60156ebffc43da201bc3",
    "url": "/static/js/2.10fa71fb.chunk.js"
  },
  {
    "revision": "27a91ff1da48a321f4a4",
    "url": "/static/js/20.6f2f820b.chunk.js"
  },
  {
    "revision": "45775f196e271f1d1ca7",
    "url": "/static/js/21.2526a3e7.chunk.js"
  },
  {
    "revision": "fa3d5b5d4a78efb633d7",
    "url": "/static/js/22.d01bde14.chunk.js"
  },
  {
    "revision": "b638cfac0840f4a0dbe2",
    "url": "/static/js/23.97bd2562.chunk.js"
  },
  {
    "revision": "9b2f4169ad0c247ff364",
    "url": "/static/js/24.18700eb5.chunk.js"
  },
  {
    "revision": "e5b1a7b02eef5e28d508",
    "url": "/static/js/25.8ede2fe7.chunk.js"
  },
  {
    "revision": "c3fb3bffd09bdaa5c3d7",
    "url": "/static/js/26.1a8fe0b6.chunk.js"
  },
  {
    "revision": "d9f1dc200485194a9fde",
    "url": "/static/js/3.b28ed83f.chunk.js"
  },
  {
    "revision": "06e7efc2e13b48c31b62",
    "url": "/static/js/4.22ead30a.chunk.js"
  },
  {
    "revision": "97636669c8193ace9a3b4f1548fc4d0b",
    "url": "/static/js/4.22ead30a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "cf45c131b50a81a9c60b",
    "url": "/static/js/5.643ceaec.chunk.js"
  },
  {
    "revision": "698aeceff16ed25bec0e",
    "url": "/static/js/6.75719241.chunk.js"
  },
  {
    "revision": "44d110ffd34196d2f02a",
    "url": "/static/js/9.753f26a9.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/9.753f26a9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "32f6e92e72b75f92cda6",
    "url": "/static/js/main.40f0d390.chunk.js"
  },
  {
    "revision": "59f89dedee882f1f2e55",
    "url": "/static/js/runtime-main.fc5fcda0.js"
  },
  {
    "revision": "9de4c31fdd970c54c14714bf89a4024c",
    "url": "/static/media/banner-1.9de4c31f.jpg"
  },
  {
    "revision": "cc9ad140dc7f365f262e1a6b6014cab4",
    "url": "/static/media/banner-2.cc9ad140.jpg"
  },
  {
    "revision": "3fab5b16fed74756b00ab9cd24a43a4c",
    "url": "/static/media/banner-3.3fab5b16.jpg"
  },
  {
    "revision": "8b2cc70dc47e8b446044cdc35a98c380",
    "url": "/static/media/banner-4.8b2cc70d.jpg"
  },
  {
    "revision": "2eba9da594f51e975aecc52a335fc879",
    "url": "/static/media/banner-5.2eba9da5.jpg"
  },
  {
    "revision": "0939825f42533d081beaaea3ad767909",
    "url": "/static/media/banner-6.0939825f.jpg"
  },
  {
    "revision": "df2d138bbdea54e4bcca33470a474a13",
    "url": "/static/media/banner-7.df2d138b.jpg"
  },
  {
    "revision": "82e0a37b248c1d182332e61f121d781f",
    "url": "/static/media/cart-bg.82e0a37b.png"
  },
  {
    "revision": "8c5f88d4328600aeeba800da3f8b9811",
    "url": "/static/media/coupon_bg.8c5f88d4.png"
  },
  {
    "revision": "afe0e541c62ee8a38a07de6c41591fa3",
    "url": "/static/media/iconfont.afe0e541.svg"
  },
  {
    "revision": "b240605dcc506d672abe897ba12ad596",
    "url": "/static/media/iconfont.b240605d.woff"
  },
  {
    "revision": "c30e19e951f39fff771fdbde98fb8bad",
    "url": "/static/media/iconfont.c30e19e9.eot"
  },
  {
    "revision": "d184bba013ad6f01d4dc17623a998c65",
    "url": "/static/media/iconfont.d184bba0.ttf"
  },
  {
    "revision": "7c17dd637b9de16c2a576b04642ec245",
    "url": "/static/media/isVip.7c17dd63.gif"
  },
  {
    "revision": "276cf06d1638c13500136595c0a0a64d",
    "url": "/static/media/libao.276cf06d.gif"
  },
  {
    "revision": "f750c393713eaa6ea33f67fde308ec89",
    "url": "/static/media/nV3tsTMF.f750c393.gif"
  },
  {
    "revision": "b34e9e001ec5da39b689811fbf005104",
    "url": "/static/media/no-orderBg.b34e9e00.png"
  },
  {
    "revision": "8b9066faed05b2a04ee75e5f0f27dc1b",
    "url": "/static/media/nologin.8b9066fa.jpg"
  },
  {
    "revision": "274ebac56ca3925a35ab94451061bfd8",
    "url": "/static/media/setNewDay.274ebac5.jpg"
  }
]);
self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "e0ff9611cc9b5f6fac1db2e1f504998b",
    "url": "/index.html"
  },
  {
    "revision": "f38356fbaa9ac34bbf62",
    "url": "/static/css/0.0b814dd5.chunk.css"
  },
  {
    "revision": "2305991e7ff29fe31c2e",
    "url": "/static/css/1.3b4f9bce.chunk.css"
  },
  {
    "revision": "76e668e5089d9756f07e",
    "url": "/static/css/10.3715b3d8.chunk.css"
  },
  {
    "revision": "07d353e65ce4b755d581",
    "url": "/static/css/11.254bac24.chunk.css"
  },
  {
    "revision": "1656468e9c4f38870f33",
    "url": "/static/css/12.3f31cb7e.chunk.css"
  },
  {
    "revision": "3953469cf28c225650b4",
    "url": "/static/css/13.4a52d7ce.chunk.css"
  },
  {
    "revision": "b7504c444d3b0f5f531c",
    "url": "/static/css/14.a6463ee0.chunk.css"
  },
  {
    "revision": "182dde69e874d5c05c06",
    "url": "/static/css/15.ae92f0ac.chunk.css"
  },
  {
    "revision": "ec8fb42cc4b8584cc1a9",
    "url": "/static/css/16.2730d488.chunk.css"
  },
  {
    "revision": "98482cd4d73600644bde",
    "url": "/static/css/17.d671f1ec.chunk.css"
  },
  {
    "revision": "901bde7d14410ecc9eb7",
    "url": "/static/css/18.d671f1ec.chunk.css"
  },
  {
    "revision": "4ae4a049cfef2828c332",
    "url": "/static/css/19.5cfe62a4.chunk.css"
  },
  {
    "revision": "d1a4b8085325a2f2fe9f",
    "url": "/static/css/20.29dc898f.chunk.css"
  },
  {
    "revision": "893b42538e7aff42b804",
    "url": "/static/css/21.e1bb1ca0.chunk.css"
  },
  {
    "revision": "fa3d5b5d4a78efb633d7",
    "url": "/static/css/22.08e42eba.chunk.css"
  },
  {
    "revision": "03fbb440f721ac59e2c4",
    "url": "/static/css/23.11d7ff5a.chunk.css"
  },
  {
    "revision": "f54f8a5984d56362504f",
    "url": "/static/css/24.51465d1f.chunk.css"
  },
  {
    "revision": "29bda4d1209c363218ac",
    "url": "/static/css/25.6a1d9ea8.chunk.css"
  },
  {
    "revision": "0fcbf7fc13fe2ada7e5c",
    "url": "/static/css/26.2f711f5d.chunk.css"
  },
  {
    "revision": "244bd610468415abe016",
    "url": "/static/css/3.3be43204.chunk.css"
  },
  {
    "revision": "21f7d3b8b615e44494fe",
    "url": "/static/css/4.9404f3ea.chunk.css"
  },
  {
    "revision": "dc7425ae2c1331cd3c08",
    "url": "/static/css/5.f692b387.chunk.css"
  },
  {
    "revision": "00fbbd8825275d75f2f4",
    "url": "/static/css/6.cf1aac06.chunk.css"
  },
  {
    "revision": "f083a7d410005fc623b8",
    "url": "/static/css/9.189a9661.chunk.css"
  },
  {
    "revision": "32f6e92e72b75f92cda6",
    "url": "/static/css/main.705d9c9f.chunk.css"
  },
  {
    "revision": "f38356fbaa9ac34bbf62",
    "url": "/static/js/0.a06b53d5.chunk.js"
  },
  {
    "revision": "2305991e7ff29fe31c2e",
    "url": "/static/js/1.efdd0ffa.chunk.js"
  },
  {
    "revision": "76e668e5089d9756f07e",
    "url": "/static/js/10.f3f947d5.chunk.js"
  },
  {
    "revision": "07d353e65ce4b755d581",
    "url": "/static/js/11.c8b75470.chunk.js"
  },
  {
    "revision": "1656468e9c4f38870f33",
    "url": "/static/js/12.adef0f57.chunk.js"
  },
  {
    "revision": "3953469cf28c225650b4",
    "url": "/static/js/13.ad5e4ddc.chunk.js"
  },
  {
    "revision": "b7504c444d3b0f5f531c",
    "url": "/static/js/14.042028a5.chunk.js"
  },
  {
    "revision": "182dde69e874d5c05c06",
    "url": "/static/js/15.032e7f60.chunk.js"
  },
  {
    "revision": "ec8fb42cc4b8584cc1a9",
    "url": "/static/js/16.5b964022.chunk.js"
  },
  {
    "revision": "98482cd4d73600644bde",
    "url": "/static/js/17.06e184ed.chunk.js"
  },
  {
    "revision": "901bde7d14410ecc9eb7",
    "url": "/static/js/18.8ec3b5cf.chunk.js"
  },
  {
    "revision": "4ae4a049cfef2828c332",
    "url": "/static/js/19.e91b505e.chunk.js"
  },
  {
    "revision": "60156ebffc43da201bc3",
    "url": "/static/js/2.10fa71fb.chunk.js"
  },
  {
    "revision": "d1a4b8085325a2f2fe9f",
    "url": "/static/js/20.6f2f820b.chunk.js"
  },
  {
    "revision": "893b42538e7aff42b804",
    "url": "/static/js/21.2526a3e7.chunk.js"
  },
  {
    "revision": "fa3d5b5d4a78efb633d7",
    "url": "/static/js/22.d01bde14.chunk.js"
  },
  {
    "revision": "03fbb440f721ac59e2c4",
    "url": "/static/js/23.97bd2562.chunk.js"
  },
  {
    "revision": "f54f8a5984d56362504f",
    "url": "/static/js/24.18700eb5.chunk.js"
  },
  {
    "revision": "29bda4d1209c363218ac",
    "url": "/static/js/25.8ede2fe7.chunk.js"
  },
  {
    "revision": "0fcbf7fc13fe2ada7e5c",
    "url": "/static/js/26.1a8fe0b6.chunk.js"
  },
  {
    "revision": "244bd610468415abe016",
    "url": "/static/js/3.b28ed83f.chunk.js"
  },
  {
    "revision": "21f7d3b8b615e44494fe",
    "url": "/static/js/4.22ead30a.chunk.js"
  },
  {
    "revision": "97636669c8193ace9a3b4f1548fc4d0b",
    "url": "/static/js/4.22ead30a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "dc7425ae2c1331cd3c08",
    "url": "/static/js/5.643ceaec.chunk.js"
  },
  {
    "revision": "00fbbd8825275d75f2f4",
    "url": "/static/js/6.75719241.chunk.js"
  },
  {
    "revision": "f083a7d410005fc623b8",
    "url": "/static/js/9.753f26a9.chunk.js"
  },
  {
    "revision": "3453b8997016469371284a28c0e873e2",
    "url": "/static/js/9.753f26a9.chunk.js.LICENSE.txt"
  },
  {
    "revision": "32f6e92e72b75f92cda6",
    "url": "/static/js/main.40f0d390.chunk.js"
  },
  {
    "revision": "cdbd16e0646d0a598041",
    "url": "/static/js/runtime-main.ad7796db.js"
  },
  {
    "revision": "9de4c31fdd970c54c14714bf89a4024c",
    "url": "/static/media/banner-1.9de4c31f.jpg"
  },
  {
    "revision": "cc9ad140dc7f365f262e1a6b6014cab4",
    "url": "/static/media/banner-2.cc9ad140.jpg"
  },
  {
    "revision": "3fab5b16fed74756b00ab9cd24a43a4c",
    "url": "/static/media/banner-3.3fab5b16.jpg"
  },
  {
    "revision": "8b2cc70dc47e8b446044cdc35a98c380",
    "url": "/static/media/banner-4.8b2cc70d.jpg"
  },
  {
    "revision": "2eba9da594f51e975aecc52a335fc879",
    "url": "/static/media/banner-5.2eba9da5.jpg"
  },
  {
    "revision": "0939825f42533d081beaaea3ad767909",
    "url": "/static/media/banner-6.0939825f.jpg"
  },
  {
    "revision": "df2d138bbdea54e4bcca33470a474a13",
    "url": "/static/media/banner-7.df2d138b.jpg"
  },
  {
    "revision": "82e0a37b248c1d182332e61f121d781f",
    "url": "/static/media/cart-bg.82e0a37b.png"
  },
  {
    "revision": "8c5f88d4328600aeeba800da3f8b9811",
    "url": "/static/media/coupon_bg.8c5f88d4.png"
  },
  {
    "revision": "afe0e541c62ee8a38a07de6c41591fa3",
    "url": "/static/media/iconfont.afe0e541.svg"
  },
  {
    "revision": "b240605dcc506d672abe897ba12ad596",
    "url": "/static/media/iconfont.b240605d.woff"
  },
  {
    "revision": "c30e19e951f39fff771fdbde98fb8bad",
    "url": "/static/media/iconfont.c30e19e9.eot"
  },
  {
    "revision": "d184bba013ad6f01d4dc17623a998c65",
    "url": "/static/media/iconfont.d184bba0.ttf"
  },
  {
    "revision": "7c17dd637b9de16c2a576b04642ec245",
    "url": "/static/media/isVip.7c17dd63.gif"
  },
  {
    "revision": "276cf06d1638c13500136595c0a0a64d",
    "url": "/static/media/libao.276cf06d.gif"
  },
  {
    "revision": "f750c393713eaa6ea33f67fde308ec89",
    "url": "/static/media/nV3tsTMF.f750c393.gif"
  },
  {
    "revision": "b34e9e001ec5da39b689811fbf005104",
    "url": "/static/media/no-orderBg.b34e9e00.png"
  },
  {
    "revision": "8b9066faed05b2a04ee75e5f0f27dc1b",
    "url": "/static/media/nologin.8b9066fa.jpg"
  },
  {
    "revision": "274ebac56ca3925a35ab94451061bfd8",
    "url": "/static/media/setNewDay.274ebac5.jpg"
  }
]);